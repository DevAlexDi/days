$(document).ready(function(){





$(window).scroll(function() {
    
    if ($(this).scrollTop() > 200) {
    	$(".left-gran").animate({"opacity":"1","left":"50px"},1000);	 
    }
});

	












});